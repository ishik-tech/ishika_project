from django.shortcuts import render
from http import httpresponse
# Create your views here.
def abc_dj(request):
    return("hello")
