import mysql.connector as c 
con=c.connect(host="localhost",user="root",password="")
if con.is_connected():
    print("connected")
else:
    print("some connectivity issue")