# for i in range(7):
#     print(i)

# for x in range(3,9):
#     print(x)


for y in range(3,15,4):
    print(y)